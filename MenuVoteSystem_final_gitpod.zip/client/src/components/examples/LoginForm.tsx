import LoginForm from '../LoginForm';

export default function LoginFormExample() {
  return (
    <LoginForm onLogin={(user) => console.log('Login triggered:', user)} />
  );
}