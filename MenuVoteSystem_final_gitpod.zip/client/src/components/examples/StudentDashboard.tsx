import StudentDashboard from '../StudentDashboard';

export default function StudentDashboardExample() {
  return <StudentDashboard userShift="full-time" />;
}