import MenuItemCard from '../MenuItemCard';
import sandwichImage from '@assets/generated_images/School_lunch_sandwich_4b922d2d.png';

export default function MenuItemCardExample() {
  return (
    <div className="max-w-sm">
      <MenuItemCard
        id="sandwich-1"
        name="Sanduíche Natural"
        description="Sanduíche com presunto, queijo, alface e tomate no pão integral"
        image={sandwichImage}
        category="Lanches"
        votes={23}
        hasVoted={false}
        canVote={true}
        onVote={(id) => console.log('Vote triggered for:', id)}
      />
    </div>
  );
}