import Header from '../Header';

export default function HeaderExample() {
  return (
    <div className="w-full">
      <Header 
        user={{
          name: "João Silva",
          role: "student",
          shift: "morning"
        }}
        onLogout={() => console.log('Logout triggered')}
      />
    </div>
  );
}