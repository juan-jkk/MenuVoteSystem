import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { LogOut, Vote, Users, Settings } from "lucide-react";

interface HeaderProps {
  user?: {
    name: string;
    role: 'staff' | 'student';
    shift?: 'morning' | 'afternoon' | 'full-time';
  };
  onLogout?: () => void;
}

export default function Header({ user, onLogout }: HeaderProps) {
  return (
    <header className="flex items-center justify-between p-4 border-b bg-card">
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2">
          <Vote className="w-8 h-8 text-primary" />
          <h1 className="text-2xl font-bold text-foreground">MenuVote</h1>
        </div>
        {user && (
          <Badge variant="secondary" className="ml-4">
            {user.role === 'staff' ? (
              <><Settings className="w-3 h-3 mr-1" /> Staff</>
            ) : (
              <><Users className="w-3 h-3 mr-1" /> Student - {user.shift}</>
            )}
          </Badge>
        )}
      </div>
      
      {user && (
        <div className="flex items-center gap-4">
          <span className="text-sm text-muted-foreground">
            Welcome, {user.name}
          </span>
          <Button 
            variant="outline" 
            size="sm" 
            onClick={onLogout}
            data-testid="button-logout"
          >
            <LogOut className="w-4 h-4 mr-2" />
            Logout
          </Button>
        </div>
      )}
    </header>
  );
}