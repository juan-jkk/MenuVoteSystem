import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import MenuItemCard from "./MenuItemCard";
import { Vote, Clock, TrendingUp } from "lucide-react";

// Import generated images
import sandwichImage from '@assets/generated_images/School_lunch_sandwich_4b922d2d.png';
import saladImage from '@assets/generated_images/Garden_salad_bowl_c713f8f8.png';
import pizzaImage from '@assets/generated_images/Cheese_pizza_slice_db7db568.png';
import fruitImage from '@assets/generated_images/Fresh_fruit_cup_18f12d03.png';

interface StudentDashboardProps {
  userShift: 'morning' | 'afternoon' | 'full-time';
}

export default function StudentDashboard({ userShift }: StudentDashboardProps) {
  const [votedItems, setVotedItems] = useState<Set<string>>(new Set());

  // Mock data - todo: remove mock functionality
  const morningItems = [
    {
      id: "sandwich-1",
      name: "Sanduíche Natural",
      description: "Presunto, queijo, alface e tomate no pão integral",
      image: sandwichImage,
      category: "Lanches",
      votes: 23
    },
    {
      id: "fruit-1",
      name: "Salada de Frutas",
      description: "Mix de frutas frescas da estação",
      image: fruitImage,
      category: "Sobremesas",
      votes: 18
    }
  ];

  const afternoonItems = [
    {
      id: "pizza-1",
      name: "Pizza de Queijo",
      description: "Fatia de pizza com queijo mozzarella e molho de tomate",
      image: pizzaImage,
      category: "Pratos Quentes",
      votes: 31
    },
    {
      id: "salad-1",
      name: "Salada Verde",
      description: "Mix de folhas verdes com tomate cereja e cenoura",
      image: saladImage,
      category: "Saladas",
      votes: 15
    }
  ];

  const handleVote = (itemId: string) => {
    setVotedItems(prev => new Set(Array.from(prev).concat(itemId)));
  };

  const getAvailableItems = () => {
    if (userShift === 'morning') return morningItems;
    if (userShift === 'afternoon') return afternoonItems;
    return [...morningItems, ...afternoonItems]; // full-time
  };

  const getActiveSession = () => {
    const now = new Date();
    const hour = now.getHours();
    
    if (hour < 12) return 'morning';
    if (hour < 18) return 'afternoon';
    return 'closed';
  };

  const activeSession = getActiveSession();
  const canVoteInSession = (session: string) => {
    if (userShift === 'full-time') return activeSession === session;
    return userShift === session && activeSession === session;
  };

  return (
    <div className="p-6 space-y-6">
      {/* Voting Status */}
      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <Vote className="w-5 h-5 text-primary" />
            <CardTitle>Status da Votação</CardTitle>
          </div>
          <CardDescription>
            Tempo restante para votar no cardápio de hoje
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Progresso da votação</span>
              <Badge variant={activeSession !== 'closed' ? 'default' : 'secondary'}>
                {activeSession === 'closed' ? 'Votação Encerrada' : 'Votação Ativa'}
              </Badge>
            </div>
            <Progress value={75} className="w-full" />
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Clock className="w-4 h-4" />
              <span>Encerra às 14:00</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Voting Interface */}
      {userShift === 'full-time' ? (
        <Tabs defaultValue="morning" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="morning" data-testid="tab-morning">
              Lanche da Manhã
            </TabsTrigger>
            <TabsTrigger value="afternoon" data-testid="tab-afternoon">
              Lanche da Tarde
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="morning" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {morningItems.map((item) => (
                <MenuItemCard
                  key={item.id}
                  {...item}
                  hasVoted={votedItems.has(item.id)}
                  canVote={canVoteInSession('morning')}
                  onVote={handleVote}
                />
              ))}
            </div>
          </TabsContent>
          
          <TabsContent value="afternoon" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {afternoonItems.map((item) => (
                <MenuItemCard
                  key={item.id}
                  {...item}
                  hasVoted={votedItems.has(item.id)}
                  canVote={canVoteInSession('afternoon')}
                  onVote={handleVote}
                />
              ))}
            </div>
          </TabsContent>
        </Tabs>
      ) : (
        <div className="space-y-4">
          <h2 className="text-2xl font-semibold">
            {userShift === 'morning' ? 'Lanche da Manhã' : 'Lanche da Tarde'}
          </h2>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {getAvailableItems().map((item) => (
              <MenuItemCard
                key={item.id}
                {...item}
                hasVoted={votedItems.has(item.id)}
                canVote={canVoteInSession(userShift)}
                onVote={handleVote}
              />
            ))}
          </div>
        </div>
      )}

      {/* Voting Results */}
      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-primary" />
            <CardTitle>Resultados Parciais</CardTitle>
          </div>
          <CardDescription>
            Veja como está a votação até agora
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm">Pizza de Queijo</span>
              <span className="text-sm font-medium">31 votos</span>
            </div>
            <Progress value={65} />
            
            <div className="flex items-center justify-between">
              <span className="text-sm">Sanduíche Natural</span>
              <span className="text-sm font-medium">23 votos</span>
            </div>
            <Progress value={48} />
            
            <div className="flex items-center justify-between">
              <span className="text-sm">Salada de Frutas</span>
              <span className="text-sm font-medium">18 votos</span>
            </div>
            <Progress value={38} />
          </div>
        </CardContent>
      </Card>
    </div>
  );
}