import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Vote, Users, Settings } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function LoginForm() {
  const [studentId, setStudentId] = useState("");
  const [studentBirth, setStudentBirth] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleStaffLogin = () => {
    console.log('Redirecting to staff OAuth login');
    window.location.href = '/api/login';
  };

  const handleStudentLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!studentId || !studentBirth) {
      toast({
        title: "Error",
        description: "Please fill in all fields",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    try {
      await apiRequest('/api/auth/student-login', 'POST', {
        studentId,
        birthDate: studentBirth,
      });
      
      // Reload page to trigger authentication check
      window.location.reload();
    } catch (error: any) {
      console.error('Student login error:', error);
      toast({
        title: "Login Failed",
        description: error.message || "Invalid credentials",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="flex items-center justify-center gap-2 mb-2">
            <Vote className="w-8 h-8 text-primary" />
            <CardTitle className="text-2xl">MenuVote</CardTitle>
          </div>
          <CardDescription>
            Faça login para votar no cardápio escolar
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="student" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="student" data-testid="tab-student">
                <Users className="w-4 h-4 mr-2" />
                Aluno
              </TabsTrigger>
              <TabsTrigger value="staff" data-testid="tab-staff">
                <Settings className="w-4 h-4 mr-2" />
                Funcionário
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="student" className="space-y-4">
              <form onSubmit={handleStudentLogin} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="student-id">Matrícula</Label>
                  <Input
                    id="student-id"
                    type="text"
                    placeholder="Digite sua matrícula"
                    value={studentId}
                    onChange={(e) => setStudentId(e.target.value)}
                    data-testid="input-student-id"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="student-birth">Data de Nascimento</Label>
                  <Input
                    id="student-birth"
                    type="date"
                    value={studentBirth}
                    onChange={(e) => setStudentBirth(e.target.value)}
                    data-testid="input-student-birth"
                    required
                  />
                </div>
                <Button 
                  type="submit" 
                  className="w-full" 
                  data-testid="button-student-login"
                  disabled={isLoading}
                >
                  {isLoading ? "Entrando..." : "Entrar como Aluno"}
                </Button>
              </form>
            </TabsContent>
            
            <TabsContent value="staff" className="space-y-4">
              <div className="space-y-4 text-center">
                <p className="text-sm text-muted-foreground">
                  Funcionários fazem login usando sua conta institucional
                </p>
                <Button 
                  onClick={handleStaffLogin} 
                  className="w-full" 
                  data-testid="button-staff-login"
                >
                  Entrar com Conta Institucional
                </Button>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}