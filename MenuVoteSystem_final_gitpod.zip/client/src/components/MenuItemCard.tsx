import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Heart, Users, Clock } from "lucide-react";

interface MenuItemCardProps {
  id: string;
  name: string;
  description: string;
  image: string;
  category: string;
  votes: number;
  hasVoted?: boolean;
  canVote?: boolean;
  onVote?: (id: string) => void;
}

export default function MenuItemCard({
  id,
  name,
  description,
  image,
  category,
  votes,
  hasVoted = false,
  canVote = true,
  onVote
}: MenuItemCardProps) {
  const [isVoting, setIsVoting] = useState(false);

  const handleVote = async () => {
    if (!canVote || hasVoted) return;
    
    setIsVoting(true);
    console.log('Voting for item:', id);
    
    // Simulate API call
    setTimeout(() => {
      onVote?.(id);
      setIsVoting(false);
    }, 500);
  };

  return (
    <Card className={`overflow-hidden hover-elevate ${hasVoted ? 'ring-2 ring-primary' : ''}`}>
      <CardHeader className="p-0">
        <div className="relative h-48 overflow-hidden">
          <img 
            src={image} 
            alt={name}
            className="w-full h-full object-cover"
          />
          <div className="absolute top-2 left-2">
            <Badge variant="secondary">{category}</Badge>
          </div>
          {hasVoted && (
            <div className="absolute top-2 right-2">
              <Badge variant="default" className="bg-primary">
                <Heart className="w-3 h-3 mr-1 fill-current" />
                Votado
              </Badge>
            </div>
          )}
        </div>
      </CardHeader>
      
      <CardContent className="p-4">
        <CardTitle className="text-lg mb-2">{name}</CardTitle>
        <p className="text-sm text-muted-foreground mb-3">{description}</p>
        
        <div className="flex items-center gap-4 text-sm text-muted-foreground">
          <div className="flex items-center gap-1">
            <Users className="w-4 h-4" />
            <span>{votes} votos</span>
          </div>
          <div className="flex items-center gap-1">
            <Clock className="w-4 h-4" />
            <span>Disponível hoje</span>
          </div>
        </div>
      </CardContent>
      
      <CardFooter className="p-4 pt-0">
        <Button 
          className="w-full"
          variant={hasVoted ? "secondary" : "default"}
          disabled={!canVote || isVoting}
          onClick={handleVote}
          data-testid={`button-vote-${id}`}
        >
          {isVoting ? (
            "Votando..."
          ) : hasVoted ? (
            "Voto Confirmado"
          ) : (
            "Votar neste item"
          )}
        </Button>
      </CardFooter>
    </Card>
  );
}