import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Plus, Edit, Trash2, BarChart3, Settings, Users, Vote } from "lucide-react";

// Import generated images
import sandwichImage from '@assets/generated_images/School_lunch_sandwich_4b922d2d.png';
import saladImage from '@assets/generated_images/Garden_salad_bowl_c713f8f8.png';
import pizzaImage from '@assets/generated_images/Cheese_pizza_slice_db7db568.png';
import fruitImage from '@assets/generated_images/Fresh_fruit_cup_18f12d03.png';

export default function AdminDashboard() {
  const [selectedTab, setSelectedTab] = useState("menu");
  const [menuItems, setMenuItems] = useState([
    // Mock data - todo: remove mock functionality
    {
      id: "1",
      name: "Sanduíche Natural",
      description: "Presunto, queijo, alface e tomate no pão integral",
      category: "Lanches",
      image: sandwichImage,
      available: true,
      votes: 23
    },
    {
      id: "2", 
      name: "Pizza de Queijo",
      description: "Fatia de pizza com queijo mozzarella",
      category: "Pratos Quentes",
      image: pizzaImage,
      available: true,
      votes: 31
    },
    {
      id: "3",
      name: "Salada Verde",
      description: "Mix de folhas verdes com tomate cereja",
      category: "Saladas", 
      image: saladImage,
      available: false,
      votes: 15
    },
    {
      id: "4",
      name: "Salada de Frutas",
      description: "Mix de frutas frescas da estação",
      category: "Sobremesas",
      image: fruitImage,
      available: true,
      votes: 18
    }
  ]);

  const [newItem, setNewItem] = useState({
    name: "",
    description: "",
    category: "",
  });

  const handleAddItem = () => {
    if (newItem.name && newItem.description && newItem.category) {
      const item = {
        id: Date.now().toString(),
        ...newItem,
        image: sandwichImage, // Default image
        available: true,
        votes: 0
      };
      setMenuItems([...menuItems, item]);
      setNewItem({ name: "", description: "", category: "" });
      console.log('Added new item:', item);
    }
  };

  const toggleItemAvailability = (id: string) => {
    setMenuItems(items =>
      items.map(item =>
        item.id === id ? { ...item, available: !item.available } : item
      )
    );
  };

  const deleteItem = (id: string) => {
    setMenuItems(items => items.filter(item => item.id !== id));
    console.log('Deleted item:', id);
  };

  return (
    <div className="p-6 space-y-6">
      {/* Dashboard Overview */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total de Itens</CardTitle>
            <Settings className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{menuItems.length}</div>
            <p className="text-xs text-muted-foreground">
              {menuItems.filter(i => i.available).length} disponíveis
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Votos Hoje</CardTitle>
            <Vote className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">87</div>
            <p className="text-xs text-muted-foreground">
              +12% desde ontem
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Participação</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">73%</div>
            <p className="text-xs text-muted-foreground">
              dos alunos votaram
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Item Popular</CardTitle>
            <BarChart3 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">Pizza</div>
            <p className="text-xs text-muted-foreground">
              31 votos
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Admin Tabs */}
      <Tabs value={selectedTab} onValueChange={setSelectedTab} className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="menu" data-testid="tab-menu">
            Gerenciar Cardápio
          </TabsTrigger>
          <TabsTrigger value="voting" data-testid="tab-voting">
            Sessões de Votação
          </TabsTrigger>
          <TabsTrigger value="results" data-testid="tab-results">
            Resultados
          </TabsTrigger>
        </TabsList>

        <TabsContent value="menu" className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-semibold">Itens do Cardápio</h2>
            <Dialog>
              <DialogTrigger asChild>
                <Button data-testid="button-add-item">
                  <Plus className="w-4 h-4 mr-2" />
                  Adicionar Item
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Novo Item do Cardápio</DialogTitle>
                  <DialogDescription>
                    Adicione um novo item para as votações
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="item-name">Nome do Item</Label>
                    <Input
                      id="item-name"
                      value={newItem.name}
                      onChange={(e) => setNewItem({...newItem, name: e.target.value})}
                      placeholder="Ex: Sanduíche Natural"
                      data-testid="input-item-name"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="item-description">Descrição</Label>
                    <Textarea
                      id="item-description"
                      value={newItem.description}
                      onChange={(e) => setNewItem({...newItem, description: e.target.value})}
                      placeholder="Descreva os ingredientes e preparo"
                      data-testid="input-item-description"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="item-category">Categoria</Label>
                    <Select value={newItem.category} onValueChange={(value) => setNewItem({...newItem, category: value})}>
                      <SelectTrigger data-testid="select-item-category">
                        <SelectValue placeholder="Selecione uma categoria" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Lanches">Lanches</SelectItem>
                        <SelectItem value="Pratos Quentes">Pratos Quentes</SelectItem>
                        <SelectItem value="Saladas">Saladas</SelectItem>
                        <SelectItem value="Sobremesas">Sobremesas</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <Button onClick={handleAddItem} className="w-full" data-testid="button-save-item">
                    Salvar Item
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>

          <div className="grid gap-4">
            {menuItems.map((item) => (
              <Card key={item.id}>
                <CardContent className="flex items-center justify-between p-6">
                  <div className="flex items-center gap-4">
                    <img 
                      src={item.image} 
                      alt={item.name}
                      className="w-16 h-16 rounded-lg object-cover"
                    />
                    <div>
                      <h3 className="font-semibold">{item.name}</h3>
                      <p className="text-sm text-muted-foreground">{item.description}</p>
                      <div className="flex items-center gap-2 mt-2">
                        <Badge variant="outline">{item.category}</Badge>
                        <Badge variant={item.available ? "default" : "secondary"}>
                          {item.available ? "Disponível" : "Indisponível"}
                        </Badge>
                        <span className="text-xs text-muted-foreground">{item.votes} votos</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => toggleItemAvailability(item.id)}
                      data-testid={`button-toggle-${item.id}`}
                    >
                      {item.available ? "Desativar" : "Ativar"}
                    </Button>
                    <Button variant="outline" size="sm" data-testid={`button-edit-${item.id}`}>
                      <Edit className="w-4 h-4" />
                    </Button>
                    <Button 
                      variant="destructive" 
                      size="sm"
                      onClick={() => deleteItem(item.id)}
                      data-testid={`button-delete-${item.id}`}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="voting" className="space-y-4">
          <h2 className="text-2xl font-semibold">Sessões de Votação</h2>
          <Card>
            <CardHeader>
              <CardTitle>Votação Ativa</CardTitle>
              <CardDescription>Configure as votações do dia</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between p-4 border rounded-lg">
                <div>
                  <h4 className="font-semibold">Lanche da Manhã</h4>
                  <p className="text-sm text-muted-foreground">Encerra às 10:30</p>
                </div>
                <Badge variant="default">Ativa</Badge>
              </div>
              <div className="flex items-center justify-between p-4 border rounded-lg">
                <div>
                  <h4 className="font-semibold">Lanche da Tarde</h4>
                  <p className="text-sm text-muted-foreground">Encerra às 14:00</p>
                </div>
                <Badge variant="secondary">Programada</Badge>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="results" className="space-y-4">
          <h2 className="text-2xl font-semibold">Resultados das Votações</h2>
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Ranking Manhã</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center justify-between">
                  <span>1. Sanduíche Natural</span>
                  <Badge>23 votos</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span>2. Salada de Frutas</span>
                  <Badge variant="secondary">18 votos</Badge>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Ranking Tarde</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center justify-between">
                  <span>1. Pizza de Queijo</span>
                  <Badge>31 votos</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span>2. Salada Verde</span>
                  <Badge variant="secondary">15 votos</Badge>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}