# Guia Gitpod — MenuVoteSystem

## 1) Criar repositório no GitHub
1. Vá para https://github.com/new
2. Nome do repositório: `MenuVoteSystem`
3. Público → **Create repository**

## 2) Upload dos arquivos
- Faça upload de TODO o conteúdo deste ZIP para o repositório

## 3) Abrir no Gitpod
Abra no navegador:
```
https://gitpod.io/#https://github.com/juan-jkk/MenuVoteSystem
```
O Gitpod irá:
- Construir containers (Docker)
- Subir PostgreSQL e a aplicação
- Abrir preview na porta **5000**

## 4) Testar no PC e celular
- Clique em **Open Preview** no Gitpod
- Copie a URL pública e abra no seu celular
