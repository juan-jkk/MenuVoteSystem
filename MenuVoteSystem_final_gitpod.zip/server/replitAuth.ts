import type { Express, RequestHandler } from "express";

export function setupAuth(app: Express) {
  // auth desativado para Gitpod
}

export const isAuthenticated: RequestHandler = (req, res, next) => {
  // @ts-ignore
  req.user = { claims: { sub: 'anonymous' } };
  next();
};
